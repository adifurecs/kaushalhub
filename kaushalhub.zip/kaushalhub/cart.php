<?php include 'includes/header.php';?>
<!--banner image-->
<div class="container-fluid bann_bg">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="blue"><b>Cart</b></h1>
            <div class="rd-ln-left"></div>
         </div>
      </div>
   </div>
</div>
<!--banner image ended-->
<!--feature-->
<div class="container-fluid clearfix section-padd">
   <div class="container">
      <div class="row">
         <div class="col-md-9">
            <p>1 Course in Cart</p>
            <div class="table">
               <table class="table table-bordered cart-table text-center">
                  <tr>
                     <td><a href="#"><img src="img/course3.png" class="cart-img"></a></td>
                     <td>
                        <a href="#">
                           <h4>UI/UX Design</h4>
                           <small>Confidently design beautiful user interfaces for....</small>
                        </a>
                     </td>
                     <td><a href="#" class="fa-cart"><i class="fa fa-times" aria-hidden="true"></i></a></td>
                     <td>
                        <div class="row">
                           <div class="col-md-9 padd-rt-0"> <span class="text-red"><i class="fa fa-inr" aria-hidden="true"></i><b>1,000 </b></span><br>
                              <span class="cancel-price"> <i class="fa fa-inr" aria-hidden="true"></i>15,000 </span>
                           </div>
                           <div class="col-md-3 padd-lt-0"><i class="fa fa-tag text-red" aria-hidden="true"></i></div>
                        </div>
                     </td>
                  </tr>
               </table>
            </div>
            <!--table ended-->
         </div>
         <!--col-md-9 ended-->
         <div class="col-md-3">
            <h3>Total:</h3>
            <h1 class="mar-tp-0 black"><i class="fa fa-inr" aria-hidden="true"></i><b>1,000 </b></h1>
            <p><small><span class="cancel-price"> <i class="fa fa-inr" aria-hidden="true"></i>15,000</span>  93% off</small></p>
            <div class="clearfix"></div>
            <a href="#" class="btn btn-lg btn-block btn-danger mar-bt-20">Checkout</a>
            <div class="form-group">
               <div class="input-group coupon-btn">
                  <input type="text" class="form-control" placeholder="Apply Coupon Code" name="coupon " id="coupon">
                  <span class="input-group-addon">Apply</span>
               </div>
            </div>
         </div>
         <!--col-md-3 ended-->
      </div>
   </div>
</div>
<!--feature end-->
<!--blog-->
<div class="blog-section container-fluid">
   <div class="container">
      <div class="row">
         <div class="col-md-2">
            <img src="img/bulb.png" class="img-blog">
         </div>
         <!--colmd2 ended-->
         <div class="col-md-7">
            <h3 class="white-h3">THEREFORE ALWAYS FREE FROM REPETITION</h3>
            <p  class="white-text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
         </div>
         <!--colmd7 ended-->
         <div class="col-md-3">
            <a href="#" class="btn-link">Book A Course</a>
         </div>
         <!--colmd3 ended-->
      </div>
   </div>
</div>
<!--blog section ended-->
<?php include 'includes/footer.php';?>