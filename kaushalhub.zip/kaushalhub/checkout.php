<?php include 'includes/header.php';?>
<!--banner image-->
<div class="container-fluid bann_bg">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="blue"><b>Checkout</b></h1>
            <div class="rd-ln-left"></div>
         </div>
      </div>
   </div>
</div>
<!--banner image ended-->
<!--feature-->
<div class="container-fluid clearfix section-padd">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <h3 class="blue"><b>Billing Details:</b></h3>
            <div class="rd-ln-left"></div>
            <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                     <label>First Name <span class="required">*</span></label>
                     <input type="text" name="fname" id="fname" class="form-control" placeholder="First Name" value="" required="">
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label>Last Name <span class="required">*</span></label>
                     <input type="text" name="lname" id="lname" class="form-control" value="" placeholder="Last Name" required="">
                     <span id="lnameerror" class="error"></span>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                     <label>Company Name</label>
                     <input type="text" name="companyname" id="companyname" class="form-control" placeholder="Company Name">
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                     <label>Address <span class="required">*</span></label>
                     <input type="text" name="useraddress" id="useraddress" class="form-control" placeholder="Street address" value="" required="">
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                     <label>Town / City <span class="required">*</span></label>
                     <input type="text" name="cityname" id="cityname" class="form-control" placeholder="Town / City" required="">
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label>State <span class="required">*</span></label>
                     <input type="text" name="statename" id="statename" class="form-control" placeholder="" required="">
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label>Postcode / Zip <span class="required">*</span></label>
                     <input type="text" name="zipcode" id="zipcode" class="form-control" placeholder="Postcode / Zip" maxlength="6" value="" onkeypress="return isNumber(event)" required="">
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                     <label>Country <span class="required">*</span></label>
                     <select name="country" class="form-control" id="country" required="">
                        <option value="India">India</option>
                        <option value="Algeria">Algeria</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label>Email Address <span class="required">*</span></label>
                     <input type="email" name="emailid" id="emailid" class="form-control" value="" placeholder="" required="">
                     <span id="emailiderror" class="error"></span>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="form-group">
                     <label>Phone <span class="required">*</span></label>
                     <input type="text" name="phonenumber" id="phonenumber" placeholder="Phone" maxlength="10" onkeypress="return isNumber(event)" class="number form-control" value="" required="">
                     <span id="phonenumbererror" class="error"></span>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="form-group">
                     <div class="checkout-form-list">
                        <label>Order Notes</label>
                        <textarea id="checkout-mess" class="form-control" name="ordernotes" cols="30" rows="6" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                     </div>
                  </div>
               </div>
            </div>
            <!--row ended-->
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-6">
            <h4 class="blue"><b>Your Item (2)</b></h4>
            <table class="table cart-table">
               <tr>
                  <td class="td-width"><img src="img/course3.png" class="cart-img"></td>
                  <td>
                     <h4 class="blue mar-bt-0">UI/UX Design</h4>
                     <p  class="sky-blue mar-bt-0"><small>Confidently design beautiful user interfaces for....</small></p>
                     <span class="text-red"><i class="fa fa-inr" aria-hidden="true"></i><b>1,000 </b></span><span class="cancel-price"> <i class="fa fa-inr" aria-hidden="true"></i>15,000 </span>
                  </td>
               </tr>
               <tr>
                  <td class="td-width"><img src="img/course3.png" class="cart-img"></td>
                  <td>
                     <h4 class="blue mar-bt-0">UI/UX Design</h4>
                     <p  class="sky-blue mar-bt-0"><small>Confidently design beautiful user interfaces for....</small></p>
                     <span class="text-red"><i class="fa fa-inr" aria-hidden="true"></i><b>1,000 </b></span><span class="cancel-price"> <i class="fa fa-inr" aria-hidden="true"></i>15,000 </span>
                  </td>
               </tr>
            </table>
            <!--table ended-->
            <div class="clearfix"></div>
            <div class="tt-price mar-bt-20">
               <span class="black main-price"><b>Total : <i class="fa fa-inr"></i>2,000 </b></span> <small><span class="cancel-price"> <i class="fa fa-inr" aria-hidden="true"></i>30,000</span>  93% off</small>
            </div>
            <!--tt-price end-->
            <div class="clearfix"></div>
            <div class="payment-method">
               <div class="payment-accordion">
                  <div class="panel panel-primary">
                     <div class="panel-heading">
                        <h4 class="panel-title">
                           <label for="r11">
                           <input type="radio" id="r11" name="optionsCheckboxList1" value="cod" required="" checked="checked"> Cash on delivery
                           <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed" aria-expanded="false"></a>
                           </label>
                        </h4>
                     </div>
                     <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                        <div class="panel-body">
                           <p>Pay with cash upon delivery.</p>
                        </div>
                     </div>
                  </div>
                  <div class="panel panel-primary">
                     <div class="panel-heading">
                        <h4 class="panel-title">
                           <label for="r12">
                           <input type="radio" id="r12" name="optionsCheckboxList1" value="online" required=""> Credit &amp; Debit Cards / Netbanking / UPI
                           <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true"></a>
                           </label>
                        </h4>
                     </div>
                     <div id="collapseTwo" class="panel-collapse collapse in" aria-expanded="true" style="">
                        <div class="panel-body">
                           <p>Pay securely with:<br>
                              – Credit or Debit Cards<br>
                              – Internet Banking<br>
                              – UPI<br>
                              Powered by PayUindia.
                           </p>
                        </div>
                     </div>
                  </div>
                  <div class="panel panel-primary">
                     <div class="panel-heading">
                        <h4 class="panel-title">
                           <label for="r13">
                           <input type="radio" id="r13" name="optionsCheckboxList1" value="paytm" required=""> Pay with Paytm QR
                           <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true"></a>
                           </label>
                        </h4>
                     </div>
                     <div id="collapseThree" class="panel-collapse collapse in" aria-expanded="true" style="">
                        <div class="panel-body">
                           <p>Make your payment directly using paytm QR code.Please use your Order ID as a payment reference.</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="text-center center-block">
                  <input type="button" class="btn btn-danger btn-lg" id="placeorder" value="PLACE ORDER">
               </div>
            </div>
         </div>
         <!--col-md-9 ended-->
      </div>
   </div>
</div>
<!--feature end-->
<!--blog-->
<div class="blog-section container-fluid">
   <div class="container">
      <div class="row">
         <div class="col-md-2">
            <img src="img/bulb.png" class="img-blog">
         </div>
         <!--colmd2 ended-->
         <div class="col-md-7">
            <h3 class="white-h3">THEREFORE ALWAYS FREE FROM REPETITION</h3>
            <p  class="white-text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
         </div>
         <!--colmd7 ended-->
         <div class="col-md-3">
            <a href="#" class="btn-link">Book A Course</a>
         </div>
         <!--colmd3 ended-->
      </div>
   </div>
</div>
<!--blog section ended-->
<?php include 'includes/footer.php';?>