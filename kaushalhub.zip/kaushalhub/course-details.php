<?php include 'includes/header.php';?>
<!--feature-->
<div class="container-fluid clearfix section-padd">
   <div class="container">
      <div class="row">
         <div class="col-md-9">
            <div class="teacher-block gry-bg">
               <div class="row">
                  <!--teacher block -->
                  <div class="col-md-3">
                     <div class="mini-block">
                        <img src="https://via.placeholder.com/170x100.png" class="mini-block-img"> 
                     </div>
                     <!--miniblockended-->
                  </div>
                  <!--col-md-3 ended-->
                  <div class="col-md-6">
                     <div class="mini-block">
                        <h4 class="text-center"><span class="blue">Instructor :</span> <span class="sky-blue">Instructor name</span></h4>
                        <h4 class="text-center"><span class="blue">Category :</span> <span class="sky-blue">Designing</span></h4>
                        <h4 class="text-center"><span class="blue">Course name :</span> <span class="sky-blue">Web designing</span></h4>
                     </div>
                     <!--miniblockended-->             
                  </div>
                  <!--col-md-3 ended-->
                  <div class="col-md-3">
                     <div class="mini-block">
                        <a href="course-details.php#applycourse" class="btn btn-lg btn-primary apply-btn">Apply Now</a>
                     </div>
                  </div>
                  <!--col-md-3 ended-->
                  <!--teacher block end-->
               </div>
               <!--teacherblock ended-->
            </div>
            <!--row ended-->
            <img src="https://via.placeholder.com/555x350.png" class="course-banimg">
            <div class="clearfix"></div>
            <h1 class="blue"><b>Course Name</b></h1>
            <div class="rd-ln-left"></div>
            <h3 class="blue">Course Details</h3>
            <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
            <h3 class="blue">Course Syllabus</h3>
            <div class="panel with-nav-tabs panel-primary">
               <div class="panel-heading">
                  <ul class="nav nav-tabs">
                     <li class="active"><a href="#tab1primary" data-toggle="tab"><i class="fa fa-book"></i> Description</a></li>
                     <li><a href="#tab2primary" data-toggle="tab"><i class="fa fa-university"></i> Curriculum</a></li>
                     <li><a href="#tab3primary" data-toggle="tab"> <i class="fa fa-graduation-cap"></i> dummy text</a></li>
                     <li><a href="#tab4primary" data-toggle="tab"> <i class="fa fa-certificate"></i> Certificate</a></li>
                  </ul>
               </div>
               <div class="panel-body">
                  <div class="tab-content">
                     <div class="tab-pane fade in active" id="tab1primary">
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                     </div>
                     <!--tab1primaryended-->
                     <div class="tab-pane fade" id="tab2primary">
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                     </div>
                     <!--tab2primaryended-->
                     <div class="tab-pane fade" id="tab3primary">
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                     </div>
                     <!--tab3primaryended-->
                     <div class="tab-pane fade" id="tab4primary">
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia</p>
                     </div>
                     <!--tab4primaryended-->
                  </div>
               </div>
            </div>
            <!--panelprimary ended-->
            <div class="clearfix"></div>
            <h3 class="blue text-center"><b>Reviews</b></h3>
            <div class="rd-ln"></div>
            <div class="carousel slide" data-ride="carousel" id="quote-carousel">
               <!-- Bottom Carousel Indicators -->
               <ol class="carousel-indicators">
                  <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
                  <li data-target="#quote-carousel" data-slide-to="1"></li>
                  <li data-target="#quote-carousel" data-slide-to="2"></li>
               </ol>
               <!-- Carousel Slides / Quotes -->
               <div class="carousel-inner">
                  <!-- Quote 1 -->
                  <div class="item active">
                     <blockquote>
                        <div class="row">
                           <div class="col-sm-3 text-center">
                              <img class="img-circle" src="img/user-mini.png" >
                           </div>
                           <div class="col-sm-9">
                              <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                              <small>Someone famous</small>
                              <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                              </div>
                           </div>
                        </div>
                     </blockquote>
                  </div>
                  <!-- Quote 2 -->
                  <div class="item">
                     <blockquote>
                        <div class="row">
                           <div class="col-sm-3 text-center">
                              <img class="img-circle" src="img/user-mini.png" >
                           </div>
                           <div class="col-sm-9">
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam auctor nec lacus ut tempor. Mauris.</p>
                              <small>Someone famous</small>
                              <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                              </div>
                           </div>
                        </div>
                     </blockquote>
                  </div>
                  <!-- Quote 3 -->
                  <div class="item">
                     <blockquote>
                        <div class="row">
                           <div class="col-sm-3 text-center">
                              <img class="img-circle" src="img/user-mini.png" >
                           </div>
                           <div class="col-sm-9">
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rutrum elit in arcu blandit, eget pretium nisl accumsan. Sed ultricies commodo tortor, eu pretium mauris.</p>
                              <small>Someone famous</small>
                              <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                              </div>
                           </div>
                        </div>
                     </blockquote>
                  </div>
               </div>
               <!-- Carousel Buttons Next/Prev -->
               <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
               <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
            </div>
            <div class="clearfix"></div>
            <h3 class="blue text-center"><b></b></h3>
            <div class="text-center center-block">
               <a href="#" data-toggle="modal" data-target="#writeareview" class="btn btn-primary btn-lg">Write A Review</a>
            </div>
         </div>
         <!--colmd6ended-->
         <div class="col-md-3">
            <div class="coursefeatures">
               <h3 class="blue mar-tp-0"><b>COURSE FEATURES</b></h3>
               <div class="rd-ln-left"></div>
               <ul class="feauresul">
                  <li><i class="fa fa-file"></i> Lectures <span>9</span></li>
                  <li><i class="fa fa-clock-o"></i> Duration <span>1.5 hours</span></li>
                  <li><i class="fa fa-caret-up"></i> Skill level <span>All level</span></li>
                  <li><i class="fa fa-book"></i> Language <span>English</span></li>
                  <li><i class="fa fa-users"></i> Students <span>560</span></li>
                  <li><i class="fa fa-certificate"></i> Certificate <span>Yes</span></li>
                  <li><i class="fa fa-check-square-o"></i> Assessments <span>Yes</span></li>
               </ul>
               <!--feauresul ended-->
               <div class="clearfix"></div>
               <div class="price">
                  <span><i class="fa fa-inr"></i> 12,480</span>
               </div>
               <a href="#" class="btn btn-lg btn-block btn-danger mar-bt-20">ADD TO CART</a>
            </div>
            <!--coursefeatures ended-->
            <div class="blue-bg applycourse mar-bt-20" id="applycourse">
               <h3 class="white">Apply This Course</h3>
               <p class="white">Nulla at velit convallis lectus.</p>
               <form>
                  <div class="form-group">
                     <input type="text" class="form-control"  placeholder="Full name">
                  </div>
                  <div class="form-group">
                     <input type="email" class="form-control" placeholder="Email">
                  </div>
                  <div class="form-group">
                     <input type="text" class="form-control" placeholder="Phone number">
                  </div>
                  <button type="submit" class="btn btn-primary btn-block"><b>SUBMIT</b></button>
               </form>
            </div>
            <!--applycourse-->

            <!--advertising banner images -->

            <img src="https://via.placeholder.com/260x250.png" class="adv-banner">

            <img src="https://via.placeholder.com/260x250.png" class="adv-banner">

            <!--advertising banner images -->
         </div>
         <!--colmd3ended-->
      </div>
   </div>
</div>
<!--feature end-->

<!--similar courses-->
<div class="container-fluid clearfix gry-bg section-padd">
   <div class="container">
      <div class="row">
         <div class="row">
            <div class="col-md-9">
               <h1 class="blue"><b>Similar Courses</b></h1>
            <div class="rd-ln-left"></div>
            </div>
            <div class="col-md-3">
               <!-- Controls -->
               <div class="controls1 pull-right hidden-xs">
                  <a class="left fa fa-chevron-left btn btn-primary" href="#carousel-example"
                     data-slide="prev"></a><a class="right fa fa-chevron-right btn btn-primary" href="#carousel-example"
                     data-slide="next"></a>
               </div>
            </div>
         </div>
         <div id="carousel-example" class="carousel slide hidden-xs" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
               <div class="item active">
                  <div class="row">
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course3.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> UI/UX Design </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course2.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> HTML5 </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course1.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> Wordpress </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course4.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> CSS & CSS3 </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                  </div>
               </div>
               <div class="item">
                  <div class="row">
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course2.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> HTML5 </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course3.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> UI/UX Design </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course1.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> Wordpress </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                     <div class="col-sm-3 col-md-3">
                        <div class="info-card">
                           <img src="img/course4.png" class="similar-img" />
                           <div class="info-card-details animate">
                              <div class="info-card-header">
                                 <h1 class="blue"> CSS & CSS3 </h1>
                                 <h3> Confidently design beautiful user interfaces for.... </h3>
                                 <div>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                 </div>
                              </div>
                              <div class="info-card-detail">
                                 <!-- Description -->
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                                 <ul class="details-autor">
                                    <li class="blue"><i class="fa fa-user sky-blue"></i> John Doe</li>
                                    <li class="blue"><i class="fa fa-calendar sky-blue"></i> Aug. 24, 2015</li>
                                    <li class="blue"><i class="fa fa-inr sky-blue"></i> 15,000</li>
                                    <li class="blue"><i class="fa fa-tags sky-blue"></i> Learn: Code, HTML, CSS</li>
                                 </ul>
                                 <div class="center-block text-center">
                                    <a href="#" class="btn btn-md btn-primary"> Read More</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!--info-card ended-->
                     </div>
                     <!--colended ended-->
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--similar courses ended-->
<?php include 'includes/footer.php';?>