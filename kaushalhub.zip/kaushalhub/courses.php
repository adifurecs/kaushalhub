<?php include 'includes/header.php';?>

<!--banner image-->
<div class="container-fluid bann_bg">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="blue"><b>Category Name</b></h1>
             <div class="rd-ln-left"></div>
         </div>
      </div>
   </div>
</div>
<!--banner image ended-->
<!--feature-->
<div class="container-fluid clearfix">
   <div class="container">
      <div class="row">
         <h1 class="text-center blue"><b>Category Courses</b></h1>
         <div class="rd-ln"></div>
         <p class="text-center">Unt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
         </p>
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course3.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">UI/UX Design</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course2.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">HTML5</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course1.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Wordpress</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course4.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">CSS & CSS3</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course5.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Androin App</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course3.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">API Design</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course7.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Plugins</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course8.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Avd jQuery</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course3.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">API Design</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course7.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Plugins</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end-->
         <!--card div-->
         <div class="gallery_product col-md-6">
            <div class="blog-card alt">
               <div class="meta">
                  <div class="photo" style="background-image: url(img/course8.png)"></div>
                  <ul class="details">
                     <li class="author"><a href="#">John Doe</a></li>
                     <li class="date">Aug. 24, 2015</li>
                     <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                     <li class="tags">
                        <ul>
                           <li><a href="#">Learn</a></li>
                           <li><a href="#">Code</a></li>
                           <li><a href="#">HTML</a></li>
                           <li><a href="#">CSS</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div class="description">
                  <h1 class="blue">Avd jQuery</h1>
                  <h2>Confidently design beautiful user interfaces for....</h2>
                  <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                  <div>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                     <span class="fa fa-star checked"></span>
                  </div>
                  <p class="read-more">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
         </div>
         <!--card div end--> 
      </div>
   </div>
</div>
<!--feature end-->
<!--blog-->
<div class="blog-section container-fluid">
   <div class="container">
      <div class="row">
         <div class="col-md-2">
            <img src="img/bulb.png" class="img-blog">
         </div>
         <!--colmd2 ended-->
         <div class="col-md-7">
            <h3 class="white-h3">THEREFORE ALWAYS FREE FROM REPETITION</h3>
            <p  class="white-text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
         </div>
         <!--colmd7 ended-->
         <div class="col-md-3">
            <a href="#" class="btn-link">Book A Course</a>
         </div>
         <!--colmd3 ended-->
      </div>
   </div>
</div>
<!--blog section ended-->
<?php include 'includes/footer.php';?>