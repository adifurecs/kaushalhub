 <footer>
         <div class="container-fluid foot-bg">
            <div class="container">
               <div class="row border-tb">
                  <div class="col-md-3">
                     <h3 class="footer-title">GET IN TOUCH</h3>
                     <p><i class="fa fa-map-marker"></i> Address: Lorem Ipsum is simply dummy text, Bangalore, karnataka, India.</p>
                     <p><i class="fa fa-phone"></i> Phone: +91 99999 99999</p>
                     <p><i class="fa fa-envelope"></i> Email: info@websitedomain.com</p>
                     <p><i class="fa fa-globe"></i> Website: www.websitedomain.com</p>
                     <ul class="social-ul">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                  </div>
                  <!--colmd4 ended-->
                  <div class="col-md-3">
                     <h3 class="footer-title">Kaushal Hub</h3>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when.</p>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's </p>
                  </div>
                  <!--colmd4 ended--> 
                  <div class="col-md-3">
                     <h3 class="footer-title">NEW COURSES</h3>
                     <ul class="foot-ul">
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                        <li><a href="#">Lorem Ipsum </a></li>
                     </ul>
                  </div>
                  <!--colmd4 ended-->
                  <div class="col-md-3">
                     <h3 class="footer-title">Quick Links</h3>
                     <ul class="foot-ul">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Privacy policy</a></li>
                        <li><a href="#">Terms and conditions</a></li>
                        <li><a href="#">Contact Us</a></li>
                     </ul>
                  </div>
                  <!--colmd4 ended-->  
                                   
               </div>
               <!-- border-tb ended-->                 
               
            </div>
         </div>
         <!--foot-bg ended-->
         <div class="container-fluid copyright-bg">
            <div class="container">
               <div class="row">
                  <p class="copy-right text-center">Copyrights © 2019 Kaushalhub. All rights reserved. Designed and developed by <a href="#">Future Revolution</a></p>
               </div>
            </div>
         </div>
         <!--copyright bg ended-->
      </footer>
      <section>
         <div class="icon-social">
            <ul>
               <li><a href="#" class="fb"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
               <li><a href="#" class="gp"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
               <li><a href="#" class="tw"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
               <li><a href="#" class="li"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
               <li><a href="#" class="wat"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> </li>
               <li><a href="#" class="email"><i class="fa fa-envelope-o" aria-hidden="true"></i></a> </li>
            </ul>
         </div>
      </section>


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/wow.js"></script>
<script src="js/script.js"></script>
<script src="js/slickslider.js"></script>
<script type="text/javascript">
  $('#r11').on('click', function () {
          $(this).parent().find('a').trigger('click')
      })

      $('#r12').on('click', function () {
          $(this).parent().find('a').trigger('click')
      })

      $('#r13').on('click', function () {
          $(this).parent().find('a').trigger('click')
      })

</script>

<script type="text/javascript">
  // When the DOM is ready, run this function
$(document).ready(function() {
  //Set the carousel options
  $('#quote-carousel').carousel({
    pause: true,
    interval: 4000,
  });
});
</script>
<script>
   (function( $ ) {
   
   //Function to animate slider captions 
   function doAnimations( elems ) {
       //Cache the animationend event in a variable
       var animEndEv = 'webkitAnimationEnd animationend';
       
       elems.each(function () {
           var $this = $(this),
               $animationType = $this.data('animation');
           $this.addClass($animationType).one(animEndEv, function () {
               $this.removeClass($animationType);
           });
       });
   }
   
   //Variables on page load 
   var $myCarousel = $('#sg-carousel'),
       $firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
       
   //Initialize carousel 
   $myCarousel.carousel();
   
   //Animate captions in first slide on page load 
   doAnimations($firstAnimatingElems);
   
   //Pause carousel  
   $myCarousel.carousel('pause');
   
   
   //Other slides to be animated on carousel slide event 
   $myCarousel.on('slide.bs.carousel', function (e) {
       var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
       doAnimations($animatingElems);
   });  
   
   
   })(jQuery);  
   
             
</script>
<script>
   $(document).ready(function(){
   
   $(".filter-button").click(function(){
       var value = $(this).attr('data-filter');
       
       if(value == "all")
       {
           //$('.filter').removeClass('hidden');
           $('.filter').show('1000');
       }
       else
       {
   //            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
   //            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
           $(".filter").not('.'+value).hide('3000');
           $('.filter').filter('.'+value).show('3000');
           
       }
   });
   
   if ($(".filter-button").removeClass("active")) {
   $(this).removeClass("active");
   }
   $(this).addClass("active");
   
   });
                 
</script>
<script type="text/javascript">
   $(document).ready(function(){
   $('.testimonials-list').slick({
   dots: true,
   autoplay: true,
   prevArrow: '<span class="fa-stack testimonial-left-handle fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-caret-left fa-stack-1x"></i></span>',
   nextArrow: '<span class="fa-stack testimonial-right-handle fa-lg"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-caret-right fa-stack-1x"></i></span>',
   });
   });
</script>
<div class="positionfixed"></div>






<!-- modal for contact us  -->
<div class="modal fade" id="writeareview" tabindex="-1" role="dialog" aria-labelledby="login-form" aria-hidden="true">
   <div class="modal-dialog modal-sm">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title white">Write A Review</h4>
         </div>
         <div class="modal-body">
            <!--modal body start-->
            <div class="row">
               <form action="#" method="post">                  
                   <div class="col-md-12">
                     <div class="form-group">    
                        <input type="text" name="name" id="reviewname" class="form-control"  placeholder="Name*" required="required">
                     </div>
                  </div>
                  <!--col-md-12 ended-->     
                  <div class="col-md-12">
                     <div class="form-group">    
                        <input type="email" name="emailid" id="reviewemailid" class="form-control"  placeholder="Email*" required="required">
                     </div>
                  </div>
                  <!--col-md-12 ended--> 

                  <div class="col-md-12"> 

<div class="form-group">

  <div class="row">


<label  class="col-md-3 star-text">Rating</label>

<div class="col-md-9">
   <div class="rate">
    <input type="radio" id="star5" name="rate" value="5" />
    <label for="star5" title="text">5 stars</label>
    <input type="radio" id="star4" name="rate" value="4" />
    <label for="star4" title="text">4 stars</label>
    <input type="radio" id="star3" name="rate" value="3" />
    <label for="star3" title="text">3 stars</label>
    <input type="radio" id="star2" name="rate" value="2" />
    <label for="star2" title="text">2 stars</label>
    <input type="radio" id="star1" name="rate" value="1" />
    <label for="star1" title="text">1 star</label>
  </div>  <!--rate ended-->
  </div><!--col-md-9 ended-->

</div><!--row ended-->
  </div><!--form group ended-->  


</div>
<!--col-md-12 ended--> 


                  <div class="col-md-12">
                     <div class="form-group">    
                        <textarea class="form-control message-area" placeholder="Message" cols="50" rows="7" name="message" required="required"></textarea>
                     </div>
                  </div>
                  <!--col-md-12 ended-->     
                  <div class="col-md-12">
                     <div class="display-block text-center">
                        <input type="submit" class="btn btn-primary" value="SUBMIT REVIEW">
                     </div>
                  </div>
                  <!--col-md-12 ended-->     
               </form>
            </div>
            <!--row ended-->
            <!--modal body end-->
         </div>
      </div>
   </div>
</div>

<!-- end modal for contact us  -->
</body>
</html>