<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Kaushal Hub</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="flaticon/flaticon.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <link rel="stylesheet" type="text/css" href="css/animate.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   </head>
   <body class="home">
      <header class="header-content">
         <div class="header-top hidden-sm hidden-xs" id="header-top">
            <div class="container">
               <nav class="navbar navbar-inverse header-top__top">
                  <div class="navbar-header"><a class="navbar-brand logo__link" href="index.php"><img class="logo__image" src="img/logo.png" alt="Logo kaushal hub"></a></div>
                  <div class="nav navbar-nav navbar-left categories">
                     <a class="dropdown-toggle categories__button"><i class="glyph-icon flaticon-signs-1 categories__icon"></i><span class="categories__text">categories</span></a>
                     <div class="dropdown-catagories">
                        <ul class="dropdown-catagories__list ">
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li class="dropdown-catagories__item">
                              <a class="dropdown-catagories__link " href="#">Lorem Ispum</a><span class="glyph-icon flaticon-arrows-3 dropdown-catagories__icon"></span>
                              <div class="cate-sub">
                                 <ul class="cate-sub__list">
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                    <li class="cate-sub__item"><a class="cate-sub__link" href="#">Lorem Ispum</a></li>
                                 </ul>
                              </div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <form class="navbar-form navbar-left form-search" action="#">
                     <div class="form-search__input-group">
                        <input class="form-control form-search__input" type="text" placeholder="Search your course...">
                        <div class="form-search__btn-group">
                           <button class="btn form-search__button" type="submit"><i class="glyph-icon flaticon-search form-search__icon bold"></i></button>
                        </div>
                     </div>
                  </form>

<!--if login done show this complete div-->
                  <!--<div class="nav navbar-nav navbar-right nav-right nav-right--login">
                     <div class="nav-right__notifications">
                        <a class="nav-right__item" href="#"><i class="glyph-icon flaticon-commerce-1 nav-right__item__icon"></i><span class="nav-right__item__notification">02</span></a><a class="nav-right__item" href="#"></a>
                        <div class="nav-right__profile">
                           <i class="glyph-icon flaticon-profile-2 nav-right__profile__icon"></i><span class="nav-right__profile__status"></span>
                           <div class="profile">
                              <div class="profile__avarta"><img class="profile__image" src="img/30w.jpg" alt=""></div>
                              <a class="profile__user-name" href="#">Lorem Ispum</a><a class="profile__course" href="#"><i class="glyph-icon flaticon-profile profile__icon"></i><span class="profile__text">My profile</span></a><a class="btn btn-default button-default profile__btn" href="#">Log out</a>
                           </div>
                        </div>
                     </div>
                  </div>-->
<!--if login done show this complete div-->

<!--if not login show this complete div-->
                 <div class="nav navbar-nav navbar-right nav-right nav-right--login">
                     <div class="nav-right__notifications">
                        <a class="nav-right__item" href="#"><i class="glyph-icon flaticon-commerce-1 nav-right__item__icon"></i><span class="nav-right__item__notification">0</span></a><a class="nav-right__item" href="#"></a>
                        <div class="nav-right__profile">
                           <i class="glyph-icon flaticon-profile-2 nav-right__profile__icon"></i><span class="nav-right__profile__status"></span>
                           <div class="profile">
                            
                              <a class="profile__user-name no_bord" href="#">Login</a>
                              <hr>
                              <a class="profile__user-name no_bord" href="#">Register</a>
                           </div>
                        </div>
                     </div>
                  </div>
<!--if not login show this complete div-->






               </nav>
            </div>
         </div>

         <div class="clearfix"></div>

         <div class="bottom-header hidden-sm hidden-xs" id="scrollspy" data-spy="affix" data-offset-top="112">
            <div class="container">       
               <div class="logo--menu">
                   <a class="logo__link" href="index.php"><img class="logo__image" src="img/logo.png" alt="kaushal hub"></a>            
               </div>
            </div>
         </div>

         
         <div class="header__mobile hidden-lg hidden-md">
            <div class="header-top">
               <div class="container">
                  <div class="nav-right--notlogin nav-right--notlogin--mobile">
                     <div class="logo--mobile pull-left"><a class="logo__link" href="index.php"><img class="logo__image" src="img/logo.png" alt="Kaushal Hub"></a></div>
                   <!--if user notloged in the below div has to show-->
                     <div class="nav-right__signin pull-right"><a class="nav-right__signin__link" href="#" data-toggle="modal" data-target="#modal-signin" data-modal-target="#sign-in">Log In</a><span>|</span><a class="nav-right__signin__link" href="#" data-toggle="modal" data-target="#modal-signin" data-modal-target="#sign-up">Register</a></div>
                 <!--end-->


                     <!--if user log in the below div has to show-->
                 <!-- <div class="nav-right__signin pull-right">
                      <div class="dropdown">
                          <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Sushma
                          <span class="caret"></span></button>
                          <ul class="dropdown-menu">
                            <li><a href="#" class="pad5">View profie</a></li>
                            <li><a href="#" class="pad5">cart Items(2)</a></li>
                            <li><a href="#" class="pad5">Log Out</a></li>
                          </ul>
                        </div>

                  </div>-->
                  <!--if user login end-->
                    </div>
               </div>
            </div>
            <nav class="navbar" id="header-mobile" data-spy="affix" data-offset-top="75">
               <div class="container">
                  <form class="navbar-form navbar-left form-search" action="#">
                     <div class="form-search__input-group">
                        <input class="form-control form-search__input" type="text" placeholder="Search your course...">
                        <div class="form-search__btn-group">
                           <button class="btn form-search__button" type="submit"><i class="glyph-icon flaticon-search form-search__icon bold"></i></button>
                        </div>
                     </div>
                  </form>
                  <div class="categories--mobile pull-right"><a class="dropdown-toggle categories--mobile__buttonsm" id="menu-categories" data-toggle="collapse" data-target="#dropdown-categories"><i class="glyph-icon flaticon-signs-1 categories--mobile__icon"></i></a></div>
               </div>
               <div class="menu-mobile-dropdown menu-mobile--categories">
                  <ul class="menu-mobile__list ">
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                     <li class="menu-mobile__item">
                        <a class="menu-mobile__link" href="#">Lorem Ispum</a><span class="dropdown-toggle glyph-icon flaticon-arrows-3 menu-mobile__icon" data-toggle="dropdown" onClick="void(0)"></span>
                        <ul class="dropdown-menu dropdown-mobile">
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                           <li class="dropdown-mobile__item "><a class="dropdown-mobile__link" href="#">Lorem Ispum</a></li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </nav>
         </div>
         <div class="button-default btn-ontop" id="on-top"><span class="glyph-icon flaticon-arrows-5"></span></div>
      </header>