<?php include 'includes/header.php';?>
<!--sliderr-->
<div class="container-fluid visible-lg visible-md hidden-xs hidden-sm">
   <div class="row">
      <div id="sg-carousel" class="carousel slide carousel-fade" data-ride="carousel">
         <ol class="carousel-indicators">
            <li data-target="#carousel" data-slide-to="0" class="active"></li>
            <li data-target="#carousel" data-slide-to="1" class=""></li>
            <li data-target="#carousel" data-slide-to="2" class=""></li>
            <li data-target="#carousel" data-slide-to="3" class=""></li>
         </ol>
         <!-- Carousel items -->
         <div class="carousel-inner carousel-zoom">
            <div class="item active">
               <img class="img-responsive" src="img/sl1.png" alt="">
               <div class="carousel-caption">
                  <h1  data-animation="animated zoomInLeft" class="cap-txt ">We are amazing</h1>
                  <p data-animation="animated bounceInDown">Find more about me fiverr.com/sangrai</p>
                  <button data-animation="animated bounceInUp" class="button button--tamaya button--border-thick" data-text="Send"><span>Send</span></button>
               </div>
            </div>
            <div class="item">
               <img class="img-responsive" src="img/sl1.png" alt="">
               <div class="carousel-caption animated slideInLeft">
                  <h1 data-animation="animated zoomInRight" class="cap-txt">We are innovative</h1>
                  <p data-animation="animated bounceInDown">Get start your next awesome project</p>
                  <button data-animation="animated bounceInUp" class="button button--tamaya button--border-thick" data-text="Send"><span>Send</span></button>
               </div>
            </div>
            <!-- Carousel nav -->
            <a class="carousel-control left" href="#sg-carousel" data-slide="prev">‹</a>
            <a class="carousel-control right" href="#sg-carousel" data-slide="next">›</a>
         </div>
      </div>
   </div>
   <!--sliderr-->
   <!--feature-->
   <div class="container-fluid clearfix">
      <div class="container">
         <div class="row">
            <h1 class="text-center blue"><b>Featured Courses</b></h1>
            <div class="rd-ln"></div>
            <p class="text-center">Unt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
            </p>
            <div align="center">
               <button class="btn btn-default filter-button" data-filter="all">Top Rating</button>
               <button class="btn btn-default filter-button" data-filter="hdpe">Developer</button>
               <button class="btn btn-default filter-button" data-filter="spray">Business </button>
               <button class="btn btn-default filter-button" data-filter="irrigation">Design </button>
               <button class="btn btn-default filter-button" data-filter="web">Web </button>
               <button class="btn btn-default filter-button" data-filter="photo">Photography</button>
               <button class="btn btn-default filter-button" data-filter="market">Marketing</button>
            </div>
            <br/>
            <!--card div-->
            <div class="gallery_product col-md-6 filter hdpe">
               <div class="blog-card">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course3.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">UI/UX Design</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter hdpe">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course2.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">HTML5</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter hdpe">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course1.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Wordpress</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter hdpe">
               <div class="blog-card">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course4.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">CSS & CSS3</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter hdpe">
               <div class="blog-card">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course5.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Androin App</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter spray">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course3.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">API Design</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter spray">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course7.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Plugins</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter spray">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course8.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Avd jQuery</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter irrigation">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course3.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">API Design</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter irrigation">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course7.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Plugins</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter irrigation">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course8.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Avd jQuery</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter web">
               <div class="blog-card">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course3.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">UI/UX Design</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter photo">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course2.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">HTML5</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
            <!--card div-->
            <div class="gallery_product col-md-6 filter market">
               <div class="blog-card alt">
                  <div class="meta">
                     <div class="photo" style="background-image: url(img/course1.png)"></div>
                     <ul class="details">
                        <li class="author"><a href="#">John Doe</a></li>
                        <li class="date">Aug. 24, 2015</li>
                        <li class="rupee"><i class="fa fa-inr" aria-hidden="true"></i> 15,000</li>
                        <li class="tags">
                           <ul>
                              <li><a href="#">Learn</a></li>
                              <li><a href="#">Code</a></li>
                              <li><a href="#">HTML</a></li>
                              <li><a href="#">CSS</a></li>
                           </ul>
                        </li>
                     </ul>
                  </div>
                  <div class="description">
                     <h1 class="blue">Wordpress</h1>
                     <h2>Confidently design beautiful user interfaces for....</h2>
                     <p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium,</p>
                     <div>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                     </div>
                     <p class="read-more">
                        <a href="#">Read More</a>
                     </p>
                  </div>
               </div>
            </div>
            <!--card div end-->
         </div>
      </div>
   </div>
</div>
<!--feature end-->
<!--blog-->
<div class="blog-section container-fluid">
   <div class="container">
      <div class="row">
         <div class="col-md-2">
            <img src="img/bulb.png" class="img-blog">
         </div>
         <!--colmd2 ended-->
         <div class="col-md-7">
            <h3 class="white-h3">THEREFORE ALWAYS FREE FROM REPETITION</h3>
            <p  class="white-text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour</p>
         </div>
         <!--colmd7 ended-->
         <div class="col-md-3">
            <a href="#" class="btn-link">Book A Course</a>
         </div>
         <!--colmd3 ended-->
      </div>
   </div>
</div>
<!--blog section ended-->
<!--popular course-->
<div class="container-fluid clearfix popular_padd">
   <div class="container">
      <div class="row">
         <h1 class="text-center blue"><b>Popluar Courses</b></h1>
         <div class="rd-ln"></div>
         <p class="text-center">Unt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
         </p>
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/1g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/2g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/3g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/5g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="clearfix"></div>
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/4g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/6g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/3g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
         <div class="col-md-3">
            <div class="item1">
               <img src="http://dev-clark-street.gotpantheon.com/sites/all/themes/centrum/images/icon/4g.png" class="small-icon">
               <p>Dummy text</p>
            </div>
         </div>
         <!--col-md-3 ended-->
      </div>
   </div>
</div>
<!--popular course end-->
<!--testimonial-->
<div class="container-fluid clearfix gry-bg section-padd">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <h1 class="blue"><b>News & Event</b></h1>
            <div class="rd-ln-left"></div>
            <!-- Leftaligned media object -->
            <div class="media">
               <div class="media-left"> 
                  <img src="img/course1.png" class="media-object media-latest">
               </div>
               <div class="media-body">
                  <h4 class="media-heading blue"> 
                     Dummy text 
                  </h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium</p>
                  <p class="read-more-btn">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
            <!-- Leftaligned media object ended -->
            <!-- Leftaligned media object -->
            <div class="media">
               <div class="media-left"> 
                  <img src="img/course1.png" class="media-object media-latest">
               </div>
               <div class="media-body">
                  <h4 class="media-heading blue"> 
                     Dummy text 
                  </h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium</p>
                  <p class="read-more-btn">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
            <!-- Leftaligned media object ended -->
            <!-- Leftaligned media object -->
            <div class="media">
               <div class="media-left"> 
                  <img src="img/course1.png" class="media-object media-latest">
               </div>
               <div class="media-body">
                  <h4 class="media-heading blue"> 
                     Dummy text 
                  </h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium</p>
                  <p class="read-more-btn">
                     <a href="#">Read More</a>
                  </p>
               </div>
            </div>
            <!-- Leftaligned media object ended -->
         </div>
         <!--col-md-6 ended-->
         <div class="col-md-6" id="testimonials">
            <h1 class="blue"><b>Testimonials</b></h1>
            <div class="rd-ln-left"></div>
            <div class="testimonials-list">
               <!-- Single Testimonial -->  
               <div class="single-testimonial">
                  <div class="testimonial-holder">
                     <div class="testimonial-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia
                        <div class="testimonial-caret"><i class="fa fa-caret-down"></i></div>
                     </div>
                     <div class="row">
                        <div class="testimonial-user clearfix">
                           <div class="testimonial-user-image"><img src="img/user-mini.png" alt=""></div>
                           <div class="testimonial-user-name">Dev Krishna <br> Bangalore</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- End of Single Testimonial -->  
               <!-- Single Testimonial -->  
               <div class="single-testimonial">
                  <div class="testimonial-holder">
                     <div class="testimonial-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia
                        <div class="testimonial-caret"><i class="fa fa-caret-down"></i></div>
                     </div>
                     <div class="row">
                        <div class="testimonial-user clearfix">
                           <div class="testimonial-user-image"><img src="img/user-mini.png" alt=""></div>
                           <div class="testimonial-user-name">Tom Hiddleston <br> Bangalore</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- End of Single Testimonial -->  
               <!-- Single Testimonial -->  
               <div class="single-testimonial">
                  <div class="testimonial-holder">
                     <div class="testimonial-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia
                        <div class="testimonial-caret"><i class="fa fa-caret-down"></i></div>
                     </div>
                     <div class="row">
                        <div class="testimonial-user clearfix">
                           <div class="testimonial-user-image"><img src="img/user-mini.png" alt=""></div>
                           <div class="testimonial-user-name">Robert Downey jr <br> Bangalore</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- End of Single Testimonial -->  
               <!-- Single Testimonial -->  
               <div class="single-testimonial">
                  <div class="testimonial-holder">
                     <div class="testimonial-content">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia. Adipisci animi consequatur cupiditate delectus dicta dolore dolorem ex harum ipsum laborum nobis nulla odit officia
                        <div class="testimonial-caret"><i class="fa fa-caret-down"></i></div>
                     </div>
                     <div class="row">
                        <div class="testimonial-user clearfix">
                           <div class="testimonial-user-image"><img src="img/user-mini.png" alt=""></div>
                           <div class="testimonial-user-name">Bruce Wayne<br> Bangalore</div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- End of Single Testimonial -->                                  
            </div>
            <!--testimonials listended-->
         </div>
         <!--col-md-6 ended-->
      </div>
   </div>
</div>
<!--testimonial end-->

<?php include 'includes/footer.php';?>